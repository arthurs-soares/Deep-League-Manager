const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deletar')
        .setDescription('Deleta uma guilda existente')
        .addStringOption(option =>
            option.setName('guilda')
                .setDescription('Nome da guilda para deletar')
                .setRequired(true)),

    async execute(interaction) {
        const moderatorRoles = ['1353770746660524123', '1348060399219773440']; // IDs dos cargos autorizados

        // Verificar permissões
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const isModerator = member.roles.cache.some(role => moderatorRoles.includes(role.id));
        const isLeader = guild.leader.id === interaction.user.id;

        if (!isModerator) {
            return await interaction.reply({
                content: '❌ Apenas moderadores podem deletar guildas!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const guildName = interaction.options.getString('guilda');

        // Carregar dados das guildas
        const guildsPath = path.join(__dirname, '..', 'guilds.json');

        if (!fs.existsSync(guildsPath)) {
            return await interaction.reply({
                content: '❌ Nenhuma guilda foi registrada ainda!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const guildsData = JSON.parse(fs.readFileSync(guildsPath, 'utf8'));
        const guild = guildsData.guilds[guildName.toLowerCase()];

        if (!guild) {
            return await interaction.reply({
                content: '❌ Guilda não encontrada! Verifique se o nome está correto.',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Criar embed de confirmação
        const confirmEmbed = new EmbedBuilder()
            .setTitle('⚠️ Confirmação de Exclusão')
            .setColor('#ff6b6b')
            .setDescription(`Você tem certeza que deseja deletar a guilda **${guild.name}**?`)
            .addFields(
                { name: '🏰 Guilda', value: guild.name, inline: true },
                { name: '👑 Leader', value: `<@${guild.leader.id}>`, inline: true },
                { name: '⭐ Co-Leader', value: `<@${guild.coLeader.id}>`, inline: true }
            );

        // Adicionar main roster se existir
        if (guild.mainRoster.length > 0) {
            const mainRosterText = guild.mainRoster.map(p => `<@${p.id}>`).join('\n');
            confirmEmbed.addFields({ name: '🛡️ Main Roster', value: mainRosterText, inline: true });
        }

        // Adicionar sub roster se existir
        if (guild.subRoster.length > 0) {
            const subRosterText = guild.subRoster.map(p => `<@${p.id}>`).join('\n');
            confirmEmbed.addFields({ name: '⚔️ Sub Roster', value: subRosterText, inline: true });
        }

        confirmEmbed.addFields(
            { name: '📅 Criada em', value: `<t:${Math.floor(new Date(guild.createdAt).getTime() / 1000)}:F>`, inline: false },
            { name: '⚠️ Atenção', value: '**Esta ação não pode ser desfeita!**', inline: false }
        )
        .setTimestamp();

        // Criar botões de confirmação
        const confirmButton = new ButtonBuilder()
            .setCustomId(`delete_guild_${guildName.toLowerCase()}`)
            .setLabel('🗑️ Deletar')
            .setStyle(ButtonStyle.Danger);

        const cancelButton = new ButtonBuilder()
            .setCustomId('cancel_delete')
            .setLabel('❌ Cancelar')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder()
            .addComponents(confirmButton, cancelButton);

        const response = await interaction.reply({
            embeds: [confirmEmbed],
            components: [row],
            flags: 64 // EPHEMERAL flag
        });

        // Collector para os botões
        const collector = response.createMessageComponentCollector({ time: 30000 });

        collector.on('collect', async i => {
            if (i.user.id !== interaction.user.id) {
                return await i.reply({
                    content: '❌ Apenas quem executou o comando pode confirmar!',
                    flags: 64 // EPHEMERAL flag
                });
            }

            if (i.customId === `delete_guild_${guildName.toLowerCase()}`) {
                // Deletar a guilda
                delete guildsData.guilds[guildName.toLowerCase()];
                fs.writeFileSync(guildsPath, JSON.stringify(guildsData, null, 2));

                // Criar embed de sucesso
                const successEmbed = new EmbedBuilder()
                    .setTitle('✅ Guilda Deletada com Sucesso!')
                    .setColor('#00ff00')
                    .setDescription(`A guilda **${guild.name}** foi deletada permanentemente.`)
                    .addFields(
                        { name: '🗑️ Deletada por', value: `<@${interaction.user.id}>`, inline: true },
                        { name: '📅 Deletada em', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                    )
                    .setTimestamp();

                await i.update({
                    embeds: [successEmbed],
                    components: []
                });

                // Enviar notificação no canal de visualização (se configurado)
                await sendDeletionNotification(interaction, guild);

                // Log no console
                console.log(`🗑️ Guilda "${guild.name}" deletada por ${interaction.user.username} (${interaction.user.id})`);

            } else if (i.customId === 'cancel_delete') {
                // Cancelar exclusão
                const cancelEmbed = new EmbedBuilder()
                    .setTitle('❌ Exclusão Cancelada')
                    .setColor('#95a5a6')
                    .setDescription(`A exclusão da guilda **${guild.name}** foi cancelada.`)
                    .setTimestamp();

                await i.update({
                    embeds: [cancelEmbed],
                    components: []
                });
            }
        });

        collector.on('end', async () => {
            // Verificar se a interação ainda está ativa
            try {
                await interaction.editReply({
                    components: []
                });
            } catch (error) {
                // Interação já foi atualizada ou expirou
            }
        });
    },
};

// Função para enviar notificação de exclusão no canal configurado
async function sendDeletionNotification(interaction, guild) {
    try {
        // Carregar configurações
        const configPath = path.join(__dirname, '..', 'config.json');

        if (!fs.existsSync(configPath)) {
            return;
        }

        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

        if (!config.guildViewChannel) {
            return;
        }

        // Buscar o canal
        const channel = await interaction.client.channels.fetch(config.guildViewChannel);

        if (!channel) {
            return;
        }

        // Criar embed de notificação
        const notificationEmbed = new EmbedBuilder()
            .setTitle('🗑️ Guilda Deletada')
            .setColor('#ff6b6b')
            .setDescription(`A guilda **${guild.name}** foi deletada.`)
            .addFields(
                { name: '👑 Leader', value: `<@${guild.leader.id}>`, inline: true },
                { name: '⭐ Co-Leader', value: `<@${guild.coLeader.id}>`, inline: true },
                { name: '🗑️ Deletada por', value: `<@${interaction.user.id}>`, inline: true }
            )
            .setTimestamp();

        // Enviar no canal
        await channel.send({ 
            content: `🗑️ **Guilda Deletada**`,
            embeds: [notificationEmbed] 
        });

        console.log(`📺 Notificação de exclusão da guilda "${guild.name}" enviada para o canal ${channel.name}`);

    } catch (error) {
        console.error('❌ Erro ao enviar notificação de exclusão:', error);
    }
}