const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('registrar')
        .setDescription('Registra uma nova guilda')
        .addStringOption(option =>
            option.setName('nome')
                .setDescription('Nome da guilda')
                .setRequired(true)
                .setMaxLength(50))
        .addUserOption(option =>
            option.setName('leader')
                .setDescription('Leader da guilda')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('co-leader')
                .setDescription('Co-Leader da guilda')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('main')
                .setDescription('Main Roster - IDs dos jogadores separados por vírgula (máx. 5)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('sub')
                .setDescription('Sub Roster - IDs dos jogadores separados por vírgula (máx. 5)')
                .setRequired(false)),

    async execute(interaction) {
        const moderatorRoles = ['1353770746660524123', '1348060399219773440']; // IDs dos cargos autorizados

        // Verificar se o usuário é moderador
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const isModerator = member.roles.cache.some(role => moderatorRoles.includes(role.id));

        if (!isModerator) {
            return await interaction.reply({
                content: '❌ Apenas moderadores podem registrar novas guildas!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const guildName = interaction.options.getString('nome');
        const leader = interaction.options.getUser('leader');
        const coLeader = interaction.options.getUser('co-leader');

        // Verificar se leader e co-leader são diferentes
        if (leader.id === coLeader.id) {
            return await interaction.reply({
                content: '❌ O Leader e Co-Leader devem ser pessoas diferentes!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Verificar se são membros do servidor
        try {
            await interaction.guild.members.fetch(leader.id);
            await interaction.guild.members.fetch(coLeader.id);
        } catch (error) {
            return await interaction.reply({
                content: '❌ Leader ou Co-Leader não são membros deste servidor!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Processar Main Roster
        const mainRosterInput = interaction.options.getString('main');
        let mainRoster = [];

        if (mainRosterInput) {
            const mainIds = mainRosterInput.split(',').map(id => id.trim()).filter(id => id);

            if (mainIds.length > 5) {
                return await interaction.reply({
                    content: '❌ O Main Roster pode ter no máximo 5 jogadores!',
                    flags: 64 // EPHEMERAL flag
                });
            }

            for (const id of mainIds) {
                // Remover menções se houver
                const cleanId = id.replace(/[<@!>]/g, '');

                try {
                    // Primeiro tenta buscar como membro do servidor
                    let user, member;
                    try {
                        member = await interaction.guild.members.fetch(cleanId);
                        user = member.user;
                    } catch (memberError) {
                        // Se não conseguir buscar como membro, tenta buscar como usuário global
                        try {
                            user = await interaction.client.users.fetch(cleanId);
                            // Verifica se o usuário é membro do servidor
                            await interaction.guild.members.fetch(cleanId);
                        } catch (userError) {
                            throw new Error('User not found');
                        }
                    }

                    mainRoster.push({
                        id: user.id,
                        username: user.username,
                        displayName: member ? member.displayName : user.displayName || user.username
                    });
                } catch (error) {
                    return await interaction.reply({
                        content: `❌ O jogador com ID ${cleanId} não foi encontrado ou não é membro deste servidor!`,
                        flags: 64 // EPHEMERAL flag
                    });
                }
            }
        }

        // Processar Sub Roster
        const subRosterInput = interaction.options.getString('sub');
        let subRoster = [];

        if (subRosterInput) {
            const subIds = subRosterInput.split(',').map(id => id.trim()).filter(id => id);

            if (subIds.length > 5) {
                return await interaction.reply({
                    content: '❌ O Sub Roster pode ter no máximo 5 jogadores!',
                    flags: 64 // EPHEMERAL flag
                });
            }

            for (const id of subIds) {
                // Remover menções se houver
                const cleanId = id.replace(/[<@!>]/g, '');

                try {
                    // Primeiro tenta buscar como membro do servidor
                    let user, member;
                    try {
                        member = await interaction.guild.members.fetch(cleanId);
                        user = member.user;
                    } catch (memberError) {
                        // Se não conseguir buscar como membro, tenta buscar como usuário global
                        try {
                            user = await interaction.client.users.fetch(cleanId);
                            // Verifica se o usuário é membro do servidor
                            await interaction.guild.members.fetch(cleanId);
                        } catch (userError) {
                            throw new Error('User not found');
                        }
                    }

                    subRoster.push({
                        id: user.id,
                        username: user.username,
                        displayName: member ? member.displayName : user.displayName || user.username
                    });
                } catch (error) {
                    return await interaction.reply({
                        content: `❌ O jogador com ID ${cleanId} não foi encontrado ou não é membro deste servidor!`,
                        flags: 64 // EPHEMERAL flag
                    });
                }
            }
        }

        // Verificar duplicatas entre rosters
        if (mainRoster.length > 0 && subRoster.length > 0) {
            const mainIds = mainRoster.map(p => p.id);
            const subIds = subRoster.map(p => p.id);
            const duplicates = mainIds.filter(id => subIds.includes(id));

            if (duplicates.length > 0) {
                return await interaction.reply({
                    content: '❌ Um jogador não pode estar em ambos os rosters ao mesmo tempo!',
                    flags: 64 // EPHEMERAL flag
                });
            }
        }

        // Carregar dados das guildas
        const guildsPath = path.join(__dirname, '..', 'guilds.json');
        let guildsData = { guilds: {} };

        if (fs.existsSync(guildsPath)) {
            guildsData = JSON.parse(fs.readFileSync(guildsPath, 'utf8'));
        }

        // Verificar se a guilda já existe
        if (guildsData.guilds[guildName.toLowerCase()]) {
            return await interaction.reply({
                content: '❌ Já existe uma guilda com este nome!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Verificar se o usuário já é leader de outra guilda
        const existingGuild = Object.values(guildsData.guilds).find(guild => 
            guild.leader.id === interaction.user.id
        );

        if (existingGuild) {
            return await interaction.reply({
                content: `❌ Você já é leader da guilda "${existingGuild.name}"!`,
                flags: 64 // EPHEMERAL flag
            });
        }

        // Criar nova guilda
        const newGuild = {
            name: guildName,
            leader: {
                id: leader.id,
                username: leader.username,
                displayName: leader.displayName
            },
            coLeader: {
                id: coLeader.id,
                username: coLeader.username,
                displayName: coLeader.displayName
            },
            mainRoster: mainRoster, // Agora já incluído no registro
            subRoster: subRoster,   // Agora já incluído no registro
            logo: null,
            description: null,
            link: null,
            createdBy: interaction.user.id,
            createdAt: new Date().toISOString(),
            serverId: interaction.guild.id
        };

        // Salvar guilda
        guildsData.guilds[guildName.toLowerCase()] = newGuild;
        fs.writeFileSync(guildsPath, JSON.stringify(guildsData, null, 2));

        // Criar embed de confirmação
        const confirmEmbed = new EmbedBuilder()
            .setTitle('🏰 Guilda Registrada com Sucesso!')
            .setColor('#00ff00')
            .addFields(
                { name: '📝 Nome', value: guildName, inline: true },
                { name: '👑 Leader', value: `<@${leader.id}>`, inline: true },
                { name: '⭐ Co-Leader', value: `<@${coLeader.id}>`, inline: true }
            );

        // Adicionar main roster se foi informado
        if (mainRoster.length > 0) {
            const mainRosterText = mainRoster.map(p => `<@${p.id}>`).join('\n');
            confirmEmbed.addFields({ name: '🛡️ Main Roster', value: mainRosterText, inline: true });
        }

        // Adicionar sub roster se foi informado
        if (subRoster.length > 0) {
            const subRosterText = subRoster.map(p => `<@${p.id}>`).join('\n');
            confirmEmbed.addFields({ name: '⚔️ Sub Roster', value: subRosterText, inline: true });
        }

        confirmEmbed.addFields(
            { name: '📅 Criada em', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false },
            { name: '💡 Próximo Passo', value: 'Use `/editar guilda` para modificar rosters ou adicionar logo, descrição e link!', inline: false }
        )
        .setFooter({ text: `Registrada por ${interaction.user.username}` })
        .setTimestamp();

        await interaction.reply({ embeds: [confirmEmbed] });

        // Enviar visualização automática para o canal configurado
        await sendGuildView(interaction, newGuild);

        // Log no console
        console.log(`✅ Guilda "${guildName}" registrada por ${interaction.user.username} (${interaction.user.id})`);
    },
};

// Função para enviar a visualização da guilda no canal configurado
async function sendGuildView(interaction, guild) {
    try {
        // Carregar configurações
        const configPath = path.join(__dirname, '..', 'config.json');

        if (!fs.existsSync(configPath)) {
            console.log('⚠️ Arquivo de configuração não encontrado. Canal de visualização não configurado.');
            console.log('💡 Use /definir-canal para configurar um canal de rosters.');
            return;
        }

        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

        if (!config.guildViewChannel) {
            console.log('⚠️ Canal de visualização não configurado. Use /definir-canal para configurar.');
            return;
        }

        // Buscar o canal
        const channel = await interaction.client.channels.fetch(config.guildViewChannel);

        if (!channel) {
            console.log('❌ Canal de visualização não encontrado.');
            return;
        }

        // Criar embed da guilda com design melhorado
        const guildEmbed = new EmbedBuilder()
            .setTitle(`🏰 ${guild.name}`)
            .setColor(guild.color || '#FFD700')
            .setDescription('**Nova guilda registrada no sistema!**')
            .addFields(
                { name: '👑 Leader', value: `<@${guild.leader.id}>`, inline: true },
                { name: '⭐ Co-Leader', value: `<@${guild.coLeader.id}>`, inline: true },
                { name: '📅 Registrada', value: `<t:${Math.floor(new Date(guild.createdAt).getTime() / 1000)}:R>`, inline: true }
            );

        // Adicionar main roster se existir
        if (guild.mainRoster && guild.mainRoster.length > 0) {
            const mainRosterText = guild.mainRoster.map((p, index) => `${index + 1}. <@${p.id}>`).join('\n');
            guildEmbed.addFields({ name: '🛡️ Main Roster', value: mainRosterText, inline: true });
        } else {
            guildEmbed.addFields({ name: '🛡️ Main Roster', value: '*Será definido posteriormente*', inline: true });
        }

        // Adicionar sub roster se existir
        if (guild.subRoster && guild.subRoster.length > 0) {
            const subRosterText = guild.subRoster.map((p, index) => `${index + 1}. <@${p.id}>`).join('\n');
            guildEmbed.addFields({ name: '⚔️ Sub Roster', value: subRosterText, inline: true });
        } else {
            guildEmbed.addFields({ name: '⚔️ Sub Roster', value: '*Será definido posteriormente*', inline: true });
        }

        // Adicionar descrição se existir
        if (guild.description) {
            guildEmbed.addFields({ name: '📄 Descrição', value: guild.description, inline: false });
        }

        // Adicionar link se existir
        if (guild.link) {
            guildEmbed.addFields({ name: '🔗 Link', value: guild.link, inline: false });
        }

        // Adicionar logo se existir
        if (guild.logo) {
            guildEmbed.setThumbnail(guild.logo);
        }

        guildEmbed.addFields({
            name: '📝 Registrada por',
            value: `<@${guild.createdBy}>`,
            inline: false
        });

        guildEmbed.setFooter({ text: `Use /visualizar ${guild.name} para ver detalhes completos` })
                 .setTimestamp();

        // Enviar no canal
        await channel.send({ 
            content: `🎉 **Nova Guilda Registrada!** 🎉`,
            embeds: [guildEmbed] 
        });

        console.log(`📺 Visualização da guilda "${guild.name}" enviada para o canal ${channel.name}`);

    } catch (error) {
        console.error('❌ Erro ao enviar visualização da guilda:', error);
        console.log('💡 Verifique se o canal ainda existe e se o bot tem permissões para enviar mensagens.');
    }
}