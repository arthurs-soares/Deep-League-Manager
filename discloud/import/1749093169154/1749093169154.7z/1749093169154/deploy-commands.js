const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const commands = [];

// Carregar todos os comandos da pasta commands
const commandsPath = path.join(__dirname, 'commands');

// Verificar se a pasta commands existe
if (!fs.existsSync(commandsPath)) {
    console.error('❌ Pasta /commands não encontrada!');
    process.exit(1);
}

const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

// Processar cada arquivo de comando
for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);

    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
        console.log(`✅ Comando ${command.data.name} adicionado para deploy`);
    } else {
        console.log(`⚠️ O comando em ${filePath} está faltando propriedade "data" ou "execute".`);
    }
}

// Verificar se há comandos para deploy
if (commands.length === 0) {
    console.log('❌ Nenhum comando válido encontrado para deploy!');
    process.exit(1);
}

// Configurar o REST
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

// Função para deploy dos comandos
async function deployCommands() {
    try {
        console.log(`🚀 Iniciando deploy de ${commands.length} comando(s)...`);

        // Verificar se deve fazer deploy global ou em servidor específico
        if (process.env.GUILD_ID) {
            // Deploy para servidor específico (mais rápido para testes)
            console.log(`📍 Fazendo deploy para o servidor: ${process.env.GUILD_ID}`);

            const data = await rest.put(
                Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
                { body: commands }
            );

            console.log(`✅ ${data.length} comando(s) registrado(s) no servidor com sucesso!`);
        } else {
            // Deploy global (demora até 1 hora para aparecer)
            console.log('🌍 Fazendo deploy global...');

            const data = await rest.put(
                Routes.applicationCommands(process.env.CLIENT_ID),
                { body: commands }
            );

            console.log(`✅ ${data.length} comando(s) registrado(s) globalmente!`);
            console.log('⏰ Comandos globais podem demorar até 1 hora para aparecer.');
        }

        console.log('🎉 Deploy concluído com sucesso!');

    } catch (error) {
        console.error('❌ Erro durante o deploy:', error);

        // Dar mais detalhes sobre erros comuns
        if (error.code === 50001) {
            console.log('💡 Erro: Bot não tem permissões suficientes no servidor.');
        } else if (error.code === 10013) {
            console.log('💡 Erro: CLIENT_ID ou GUILD_ID inválido.');
        } else if (error.status === 401) {
            console.log('💡 Erro: Token do bot inválido ou expirado.');
        }

        process.exit(1);
    }
}

// Executar deploy
deployCommands();