
const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ajuda')
        .setDescription('Mostra informações detalhadas sobre todos os comandos do bot')
        .addStringOption(option =>
            option.setName('comando')
                .setDescription('Comando específico para ver detalhes')
                .setRequired(false)
                .addChoices(
                    { name: 'registrar', value: 'registrar' },
                    { name: 'editar', value: 'editar' },
                    { name: 'visualizar', value: 'visualizar' },
                    { name: 'deletar', value: 'deletar' },
                    { name: 'enviar', value: 'enviar' },
                    { name: 'setscore', value: 'setscore' },
                    { name: 'definir-canal', value: 'definir-canal' },
                    { name: 'ping', value: 'ping' }
                )),

    async execute(interaction) {
        const specificCommand = interaction.options.getString('comando');

        if (specificCommand) {
            return await showSpecificCommand(interaction, specificCommand);
        }

        // Menu principal de ajuda
        const mainEmbed = new EmbedBuilder()
            .setTitle('🤖 Central de Ajuda - Deep League Brasil Bot')
            .setColor('#0099ff')
            .setDescription('**Bot oficial para gerenciamento de guildas do Deep League Brasil**\n\nSelecione uma categoria abaixo para ver os comandos disponíveis:')
            .addFields(
                {
                    name: '🏰 **Comandos de Guildas**',
                    value: '• `/registrar` - Registrar nova guilda\n• `/editar` - Editar informações da guilda\n• `/visualizar` - Ver informações das guildas\n• `/deletar` - Deletar guilda',
                    inline: false
                },
                {
                    name: '📊 **Comandos de Score**',
                    value: '• `/setscore` - Definir vitórias/derrotas',
                    inline: false
                },
                {
                    name: '⚙️ **Comandos de Moderação**',
                    value: '• `/enviar` - Enviar guilda no canal\n• `/definir-canal` - Configurar canal de rosters',
                    inline: false
                },
                {
                    name: '🔧 **Comandos Gerais**',
                    value: '• `/ping` - Verificar latência do bot\n• `/ajuda` - Mostrar esta ajuda',
                    inline: false
                },
                {
                    name: '👑 **Permissões**',
                    value: '🟢 **Todos:** `/visualizar`, `/ping`, `/ajuda`\n🟡 **Leaders:** `/editar` (própria guilda)\n🔴 **Moderadores:** Todos os comandos',
                    inline: false
                },
                {
                    name: '💡 **Dicas Importantes**',
                    value: '• Use `/ajuda comando: [nome]` para ver detalhes específicos\n• IDs de usuários podem ser obtidos clicando com botão direito\n• Nomes de usuários devem ser exatos (case-sensitive)\n• Máximo de 5 jogadores por roster (main/sub)',
                    inline: false
                }
            )
            .setFooter({ text: 'Desenvolvido para Deep League Brasil • Use /ajuda comando: [nome] para detalhes' })
            .setTimestamp();

        // Menu de seleção para navegação rápida
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('help_select')
            .setPlaceholder('🔍 Selecione um comando para ver detalhes...')
            .addOptions([
                {
                    label: 'registrar',
                    description: 'Como registrar uma nova guilda',
                    value: 'registrar',
                    emoji: '🏰'
                },
                {
                    label: 'editar',
                    description: 'Como editar informações de guildas',
                    value: 'editar',
                    emoji: '✏️'
                },
                {
                    label: 'visualizar',
                    description: 'Como visualizar guildas e rankings',
                    value: 'visualizar',
                    emoji: '👁️'
                },
                {
                    label: 'setscore',
                    description: 'Como definir scores de vitória/derrota',
                    value: 'setscore',
                    emoji: '📊'
                },
                {
                    label: 'enviar',
                    description: 'Como enviar guildas no canal',
                    value: 'enviar',
                    emoji: '📤'
                },
                {
                    label: 'definir-canal',
                    description: 'Como configurar canal de rosters',
                    value: 'definir-canal',
                    emoji: '⚙️'
                },
                {
                    label: 'deletar',
                    description: 'Como deletar guildas',
                    value: 'deletar',
                    emoji: '🗑️'
                },
                {
                    label: 'ping',
                    description: 'Verificar status do bot',
                    value: 'ping',
                    emoji: '🏓'
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        const response = await interaction.reply({
            embeds: [mainEmbed],
            components: [row]
        });

        // Collector para o menu de seleção
        const collector = response.createMessageComponentCollector({ time: 300000 }); // 5 minutos

        collector.on('collect', async i => {
            if (i.user.id !== interaction.user.id) {
                return await i.reply({
                    content: '❌ Apenas quem executou o comando pode usar este menu!',
                    flags: 64
                });
            }

            await showSpecificCommand(i, i.values[0], true);
        });

        collector.on('end', async () => {
            try {
                await interaction.editReply({
                    components: []
                });
            } catch (error) {
                // Interação já expirou ou foi deletada
            }
        });
    },
};

// Função para mostrar detalhes de um comando específico
async function showSpecificCommand(interaction, commandName, isUpdate = false) {
    const commands = {
        'registrar': {
            name: 'registrar',
            description: 'Registra uma nova guilda no sistema',
            permission: '🔴 Apenas Moderadores',
            usage: '/registrar nome: [nome] leader: [@usuário] co-leader: [@usuário] main: [opcional] sub: [opcional]',
            examples: [
                '`/registrar nome: Minha Guilda leader: @João co-leader: @Maria`',
                '`/registrar nome: Warriors leader: @Admin co-leader: @Vice main: 123456789, @jogador1 sub: @sub1, @sub2`'
            ],
            fields: [
                { name: '📝 Parâmetros Obrigatórios', value: '• `nome` - Nome da guilda (máx. 50 caracteres)\n• `leader` - Usuário que será o leader\n• `co-leader` - Usuário que será o co-leader', inline: false },
                { name: '⚔️ Parâmetros Opcionais', value: '• `main` - IDs dos jogadores do Main Roster (máx. 5)\n• `sub` - IDs dos jogadores do Sub Roster (máx. 5)', inline: false },
                { name: '⚠️ Regras Importantes', value: '• Leader e Co-Leader devem ser diferentes\n• Ambos devem ser membros do servidor\n• Nome da guilda deve ser único\n• IDs separados por vírgula', inline: false }
            ]
        },
        'editar': {
            name: 'editar',
            description: 'Edita informações de uma guilda existente',
            permission: '🟡 Moderadores ou Leader da guilda',
            usage: '/editar guilda: [nome] [parâmetros opcionais]',
            examples: [
                '`/editar guilda: Minha Guilda main: @novo1, @novo2, @novo3`',
                '`/editar guilda: Warriors logo: [anexar imagem] descricao: Melhor guilda!`',
                '`/editar guilda: Pro Team cor: #FF0000 link: discord.gg/exemplo`'
            ],
            fields: [
                { name: '🎨 Parâmetros Disponíveis', value: '• `main` - Atualizar Main Roster\n• `sub` - Atualizar Sub Roster\n• `logo` - Anexar nova logo\n• `descricao` - Descrição da guilda\n• `link` - Link/Discord da guilda\n• `cor` - Cor do embed (#hex ou nome)', inline: false },
                { name: '🔍 Como encontrar IDs', value: '• Clique com botão direito no usuário\n• Selecione "Copiar ID"\n• Use nomes de usuário exatos\n• Aceita menções (@usuário)', inline: false },
                { name: '🎨 Cores Suportadas', value: '• Códigos hex: `#FF0000`, `#00FF00`\n• Nomes: `red`, `blue`, `green`, `gold`, etc.', inline: false }
            ]
        },
        'visualizar': {
            name: 'visualizar',
            description: 'Visualiza informações de guildas e rankings',
            permission: '🟢 Todos os usuários',
            usage: '/visualizar [guilda: nome opcional]',
            examples: [
                '`/visualizar` - Ver ranking de todas as guildas',
                '`/visualizar guilda: Minha Guilda` - Ver detalhes específicos'
            ],
            fields: [
                { name: '📊 Ranking Automático', value: 'Quando usado sem parâmetros, mostra todas as guildas ordenadas por:\n• Taxa de vitória (melhor → pior)\n• Guildas sem dados aparecem por último\n• Ordenação alfabética para empates', inline: false },
                { name: '🏆 Símbolos do Ranking', value: '🥇 1º lugar • 🥈 2º lugar • 🥉 3º lugar\n🟢 Taxa ≥70% • 🟡 Taxa ≥50% • 🔴 Taxa <50%\n⚪ Sem dados de combate', inline: false },
                { name: '📈 Informações Exibidas', value: '• Rosters completos (Main e Sub)\n• Estatísticas de combate (W/L)\n• Status do roster (completo/incompleto)\n• Performance geral\n• Histórico de atualizações', inline: false }
            ]
        },
        'setscore': {
            name: 'setscore',
            description: 'Define o score (vitórias/derrotas) de uma guilda',
            permission: '🔴 Apenas usuários autorizados',
            usage: '/setscore guilda: [nome] vitorias: [número] derrotas: [número]',
            examples: [
                '`/setscore guilda: Minha Guilda vitorias: 10 derrotas: 3`',
                '`/setscore guilda: Warriors vitorias: 0 derrotas: 0` - Resetar score'
            ],
            fields: [
                { name: '📊 Funcionalidades', value: '• Define vitórias e derrotas\n• Calcula taxa de vitória automaticamente\n• Atualiza ranking das guildas\n• Registra quem fez a alteração', inline: false },
                { name: '🎯 Cálculos Automáticos', value: '• Taxa de vitória: (vitórias ÷ total) × 100\n• Total de jogos: vitórias + derrotas\n• Status de performance baseado na taxa', inline: false },
                { name: '📈 Impacto no Ranking', value: 'O score define a posição no comando `/visualizar`:\n• Guildas com melhor taxa ficam no topo\n• Influencia cores e emojis do ranking', inline: false }
            ]
        },
        'enviar': {
            name: 'enviar',
            description: 'Envia uma guilda no canal configurado',
            permission: '🔴 Apenas Moderadores',
            usage: '/enviar guilda: [nome]',
            examples: [
                '`/enviar guilda: Minha Guilda`'
            ],
            fields: [
                { name: '📤 Funcionamento', value: '• Envia embed da guilda no canal configurado\n• Mostra informações básicas da guilda\n• Inclui link para a mensagem enviada\n• Notifica sobre novos registros', inline: false },
                { name: '⚙️ Pré-requisitos', value: '• Canal deve estar configurado com `/definir-canal`\n• Bot precisa ter permissões no canal\n• Guilda deve existir no sistema', inline: false },
                { name: '📋 Informações Exibidas', value: '• Nome e logo da guilda\n• Leader e Co-Leader\n• Rosters (Main e Sub)\n• Data de registro\n• Quem registrou a guilda', inline: false }
            ]
        },
        'definir-canal': {
            name: 'definir-canal',
            description: 'Define o canal onde serão postadas as guildas',
            permission: '🔴 Apenas Moderadores',
            usage: '/definir-canal canal: [#canal]',
            examples: [
                '`/definir-canal canal: #guild-rosters`'
            ],
            fields: [
                { name: '⚙️ Configuração', value: '• Define canal para envio automático\n• Verifica permissões do bot\n• Envia mensagem de teste\n• Salva configuração permanentemente', inline: false },
                { name: '🔒 Permissões Necessárias', value: 'O bot precisa ter no canal:\n• Enviar mensagens\n• Incorporar links (embeds)\n• Ver canal', inline: false },
                { name: '📺 Uso Automático', value: '• Guildas registradas aparecem automaticamente\n• Comando `/enviar` usa este canal\n• Notificações de exclusão também', inline: false }
            ]
        },
        'deletar': {
            name: 'deletar',
            description: 'Deleta uma guilda existente',
            permission: '🔴 Apenas Moderadores',
            usage: '/deletar guilda: [nome]',
            examples: [
                '`/deletar guilda: Minha Guilda`'
            ],
            fields: [
                { name: '⚠️ Confirmação Obrigatória', value: '• Mostra preview da guilda antes de deletar\n• Botão de confirmação (30 segundos)\n• Ação irreversível - sem recuperação\n• Apenas quem executou pode confirmar', inline: false },
                { name: '📤 Notificação Automática', value: '• Envia notificação no canal configurado\n• Registra quem deletou e quando\n• Mostra informações da guilda deletada', inline: false },
                { name: '🗑️ Dados Removidos', value: '• Todos os dados da guilda\n• Rosters e informações\n• Scores e estatísticas\n• Histórico de atualizações', inline: false }
            ]
        },
        'ping': {
            name: 'ping',
            description: 'Verifica a latência e status do bot',
            permission: '🟢 Todos os usuários',
            usage: '/ping',
            examples: [
                '`/ping`'
            ],
            fields: [
                { name: '📊 Informações Exibidas', value: '• Latência da mensagem (tempo de resposta)\n• Latência da API do Discord\n• Status geral do bot', inline: false },
                { name: '💡 Utilidade', value: '• Verificar se o bot está funcionando\n• Diagnosticar problemas de conexão\n• Testar comandos básicos', inline: false }
            ]
        }
    };

    const cmd = commands[commandName];
    if (!cmd) {
        const errorEmbed = new EmbedBuilder()
            .setTitle('❌ Comando não encontrado')
            .setColor('#ff0000')
            .setDescription('O comando especificado não existe.');
        
        if (isUpdate) {
            return await interaction.update({ embeds: [errorEmbed], components: [] });
        } else {
            return await interaction.reply({ embeds: [errorEmbed], flags: 64 });
        }
    }

    const embed = new EmbedBuilder()
        .setTitle(`📖 Ajuda: /${cmd.name}`)
        .setColor('#00ff00')
        .setDescription(cmd.description)
        .addFields(
            { name: '🔐 Permissão Necessária', value: cmd.permission, inline: false },
            { name: '💬 Como Usar', value: cmd.usage, inline: false }
        );

    // Adicionar campos específicos do comando
    if (cmd.fields) {
        embed.addFields(...cmd.fields);
    }

    // Adicionar exemplos
    if (cmd.examples) {
        embed.addFields({
            name: '📝 Exemplos de Uso',
            value: cmd.examples.join('\n\n'),
            inline: false
        });
    }

    embed.addFields(
        { name: '🔙 Voltar ao Menu', value: 'Use `/ajuda` para ver todos os comandos disponíveis', inline: false }
    );

    embed.setFooter({ text: `Comando: /${cmd.name} • Deep League Brasil Bot` })
         .setTimestamp();

    if (isUpdate) {
        await interaction.update({ embeds: [embed], components: [] });
    } else {
        await interaction.reply({ embeds: [embed] });
    }
}
