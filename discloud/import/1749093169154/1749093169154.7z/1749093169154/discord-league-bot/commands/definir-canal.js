
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('definir-canal')
        .setDescription('Define o canal onde serão postadas as novas guildas registradas')
        .addChannelOption(option =>
            option.setName('canal')
                .setDescription('Canal onde as guildas serão postadas')
                .setRequired(true)),

    async execute(interaction) {
        const moderatorRoles = ['1353770746660524123', '1348060399219773440']; // IDs dos cargos autorizados

        // Verificar se o usuário é moderador
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const isModerator = member.roles.cache.some(role => moderatorRoles.includes(role.id)) || 
                           member.permissions.has('ADMINISTRATOR');

        if (!isModerator) {
            return await interaction.reply({
                content: '❌ Apenas moderadores podem definir o canal de rosters!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const channel = interaction.options.getChannel('canal');

        // Verificar se é um canal de texto
        if (channel.type !== 0) { // 0 = GUILD_TEXT
            return await interaction.reply({
                content: '❌ Por favor, selecione um canal de texto!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Verificar se o bot tem permissões no canal
        const botMember = await interaction.guild.members.fetch(interaction.client.user.id);
        const permissions = channel.permissionsFor(botMember);

        if (!permissions.has('SEND_MESSAGES') || !permissions.has('EMBED_LINKS')) {
            return await interaction.reply({
                content: '❌ O bot não tem permissões para enviar mensagens ou embeds neste canal!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Carregar ou criar configuração
        const configPath = path.join(__dirname, '..', 'config.json');
        let config = { guildViewChannel: null };

        if (fs.existsSync(configPath)) {
            config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        }

        // Atualizar configuração
        config.guildViewChannel = channel.id;

        // Salvar configuração
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));

        // Criar embed de confirmação
        const embed = new EmbedBuilder()
            .setTitle('✅ Canal de Rosters Definido!')
            .setColor('#00ff00')
            .setDescription(`O canal ${channel} foi definido como canal de rosters.`)
            .addFields(
                { name: '📺 Canal', value: `${channel}`, inline: true },
                { name: '🆔 ID do Canal', value: channel.id, inline: true },
                { name: '👤 Definido por', value: `<@${interaction.user.id}>`, inline: true }
            )
            .setFooter({ text: 'Todas as novas guildas registradas aparecerão neste canal!' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Enviar mensagem de teste no canal configurado
        try {
            const testEmbed = new EmbedBuilder()
                .setTitle('🎯 Canal de Rosters Configurado!')
                .setColor('#00ff00')
                .setDescription('Este canal foi configurado para receber notificações de novas guildas registradas.')
                .setFooter({ text: `Configurado por ${interaction.user.username}` })
                .setTimestamp();

            await channel.send({ embeds: [testEmbed] });

            console.log(`✅ Canal de rosters definido: ${channel.name} (${channel.id}) por ${interaction.user.username}`);

        } catch (error) {
            console.error('❌ Erro ao enviar mensagem de teste no canal:', error);
        }
    },
};
