
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deploy')
        .setDescription('Faz deploy manual dos comandos slash do bot')
        .addBooleanOption(option =>
            option.setName('global')
                .setDescription('Se deve fazer deploy global (padrão: apenas neste servidor)')
                .setRequired(false)),

    async execute(interaction) {
        // Verificar permissões (apenas administradores)
        if (!interaction.member.permissions.has('Administrator')) {
            return await interaction.reply({
                content: '❌ Apenas administradores podem usar este comando!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const isGlobal = interaction.options.getBoolean('global') || false;

        // Resposta inicial
        const loadingEmbed = new EmbedBuilder()
            .setTitle('⏳ Iniciando Deploy...')
            .setDescription('Carregando comandos e preparando deploy...')
            .setColor('#ffa500');

        await interaction.reply({
            embeds: [loadingEmbed],
            flags: 64 // EPHEMERAL flag
        });

        try {
            const commands = [];
            const commandsPath = path.join(__dirname);

            // Carregar todos os comandos
            const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js') && file !== 'deploy.js');

            for (const file of commandFiles) {
                const filePath = path.join(commandsPath, file);
                delete require.cache[require.resolve(filePath)]; // Limpar cache
                const command = require(filePath);

                if ('data' in command && 'execute' in command) {
                    commands.push(command.data.toJSON());
                }
            }

            if (commands.length === 0) {
                const errorEmbed = new EmbedBuilder()
                    .setTitle('❌ Erro no Deploy')
                    .setDescription('Nenhum comando válido encontrado!')
                    .setColor('#ff0000');

                return await interaction.editReply({
                    embeds: [errorEmbed]
                });
            }

            // Configurar REST
            const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

            let deployData;
            let deployLocation;

            if (isGlobal) {
                // Deploy global
                deployLocation = 'Globalmente';
                deployData = await rest.put(
                    Routes.applicationCommands(process.env.CLIENT_ID),
                    { body: commands }
                );
            } else {
                // Deploy no servidor atual
                deployLocation = `Servidor: ${interaction.guild.name}`;
                deployData = await rest.put(
                    Routes.applicationGuildCommands(process.env.CLIENT_ID, interaction.guild.id),
                    { body: commands }
                );
            }

            // Sucesso
            const successEmbed = new EmbedBuilder()
                .setTitle('✅ Deploy Concluído!')
                .setDescription(`${deployData.length} comando(s) foram atualizados com sucesso!`)
                .addFields(
                    { name: '📍 Local', value: deployLocation, inline: true },
                    { name: '📊 Comandos', value: deployData.length.toString(), inline: true },
                    { name: '⏱️ Deploy por', value: `<@${interaction.user.id}>`, inline: true }
                )
                .setColor('#00ff00')
                .setTimestamp();

            if (isGlobal) {
                successEmbed.addFields({
                    name: '⚠️ Nota',
                    value: 'Comandos globais podem demorar até 1 hora para aparecer.',
                    inline: false
                });
            }

            // Lista dos comandos deployados
            const commandList = commands.map(cmd => `• \`/${cmd.name}\` - ${cmd.description}`).join('\n');
            if (commandList.length < 1024) {
                successEmbed.addFields({
                    name: '📋 Comandos Atualizados',
                    value: commandList,
                    inline: false
                });
            }

            await interaction.editReply({
                embeds: [successEmbed]
            });

            // Log no console
            console.log(`🚀 Deploy manual executado por ${interaction.user.username} (${interaction.user.id})`);
            console.log(`📍 Local: ${deployLocation}`);
            console.log(`📊 ${deployData.length} comando(s) atualizados`);

        } catch (error) {
            console.error('❌ Erro durante deploy manual:', error);

            // Embed de erro
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Erro no Deploy')
                .setDescription('Ocorreu um erro durante o deploy dos comandos.')
                .addFields(
                    { name: '🔍 Erro', value: error.message.substring(0, 1000), inline: false }
                )
                .setColor('#ff0000')
                .setTimestamp();

            // Adicionar dicas para erros comuns
            if (error.code === 50001) {
                errorEmbed.addFields({
                    name: '💡 Dica',
                    value: 'Bot não tem permissões suficientes no servidor.',
                    inline: false
                });
            } else if (error.code === 10013) {
                errorEmbed.addFields({
                    name: '💡 Dica',
                    value: 'CLIENT_ID inválido. Verifique as variáveis de ambiente.',
                    inline: false
                });
            } else if (error.status === 401) {
                errorEmbed.addFields({
                    name: '💡 Dica',
                    value: 'Token do bot inválido ou expirado.',
                    inline: false
                });
            }

            await interaction.editReply({
                embeds: [errorEmbed]
            });
        }
    },
};
