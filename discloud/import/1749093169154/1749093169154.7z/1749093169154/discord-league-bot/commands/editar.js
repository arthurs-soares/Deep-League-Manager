const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('editar')
        .setDescription('Edita informações de uma guilda existente')
        .addStringOption(option =>
            option.setName('guilda')
                .setDescription('Nome da guilda para editar')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('main')
                .setDescription('Main Roster - IDs/nomes dos jogadores separados por vírgula (máx. 5)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('sub')
                .setDescription('Sub Roster - IDs/nomes dos jogadores separados por vírgula (máx. 5)')
                .setRequired(false))
        .addAttachmentOption(option =>
            option.setName('logo')
                .setDescription('Logo da guilda (opcional)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('descricao')
                .setDescription('Descrição da guilda (opcional)')
                .setRequired(false)
                .setMaxLength(500))
        .addStringOption(option =>
            option.setName('link')
                .setDescription('Link da guilda (opcional)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('cor')
                .setDescription('Cor do embed (hex code, ex: #FF0000 ou nome da cor)')
                .setRequired(false)),

    async execute(interaction) {
        const guildName = interaction.options.getString('guilda');
        const moderatorRoles = ['1353770746660524123', '1348060399219773440']; // IDs dos cargos autorizados

        // Carregar dados das guildas
        const guildsPath = path.join(__dirname, '..', 'guilds.json');

        if (!fs.existsSync(guildsPath)) {
            return await interaction.reply({
                content: '❌ Nenhuma guilda foi registrada ainda!',
                flags: 64
            });
        }

        const guildsData = JSON.parse(fs.readFileSync(guildsPath, 'utf8'));
        const guild = guildsData.guilds[guildName.toLowerCase()];

        if (!guild) {
            return await interaction.reply({
                content: '❌ Guilda não encontrada! Verifique se o nome está correto.',
                flags: 64
            });
        }

        // Verificar permissões
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const isModerator = member.roles.cache.some(role => moderatorRoles.includes(role.id));
        const isLeader = guild.leader.id === interaction.user.id;

        if (!isModerator && !isLeader) {
            return await interaction.reply({
                content: '❌ Você não tem permissão para editar esta guilda! Apenas moderadores ou o leader podem editá-la.',
                flags: 64
            });
        }

        // Função para buscar usuário por ID ou nome de usuário
        async function findUser(identifier) {
            // Remover menções se houver
            const cleanId = identifier.replace(/[<@!>]/g, '').trim();

            try {
                // Tentar buscar por ID primeiro
                if (/^\d{17,19}$/.test(cleanId)) {
                    try {
                        const user = await interaction.client.users.fetch(cleanId);
                        let member = null;

                        // Tentar buscar como membro
                        try {
                            member = await interaction.guild.members.fetch(cleanId);
                        } catch (memberError) {
                            // Usuário existe mas não é membro do servidor
                            console.log(`Usuário ${cleanId} encontrado mas não é membro do servidor`);
                        }

                        return {
                            user,
                            member,
                            found: true
                        };
                    } catch (error) {
                        console.log(`ID ${cleanId} não é um usuário válido`);
                    }
                }

                // Tentar buscar por nome de usuário
                const members = await interaction.guild.members.fetch();
                const foundMember = members.find(m => 
                    m.user.username.toLowerCase() === identifier.toLowerCase() ||
                    m.displayName.toLowerCase() === identifier.toLowerCase()
                );

                if (foundMember) {
                    return {
                        user: foundMember.user,
                        member: foundMember,
                        found: true
                    };
                }

                return { found: false };
            } catch (error) {
                return { found: false };
            }
        }

        // Função para processar roster com múltiplas formas de busca
        async function processRoster(rosterInput, rosterName) {
            if (!rosterInput) return [];

            const identifiers = rosterInput.split(',').map(id => id.trim()).filter(id => id);

            if (identifiers.length > 5) {
                throw new Error(`❌ O ${rosterName} pode ter no máximo 5 jogadores!`);
            }

            const roster = [];
            const notFound = [];

            for (const identifier of identifiers) {
                const result = await findUser(identifier);

                if (result.found) {
                    roster.push({
                        id: result.user.id,
                        username: result.user.username,
                        displayName: result.member ? result.member.displayName : result.user.displayName || result.user.username,
                        isMember: !!result.member
                    });
                } else {
                    notFound.push(identifier);
                }
            }

            if (notFound.length > 0) {
                throw new Error(`❌ Os seguintes jogadores não foram encontrados: ${notFound.join(', ')}\n\n**Dicas:**\n• Use o ID do usuário (números)\n• Use o nome de usuário exato\n• Certifique-se de que o usuário existe no Discord`);
            }

            return roster;
        }

        try {
            // Processar Main Roster
            const mainRosterInput = interaction.options.getString('main');
            let mainRoster = [];
            if (mainRosterInput) {
                mainRoster = await processRoster(mainRosterInput, 'Main Roster');
            }

            // Processar Sub Roster
            const subRosterInput = interaction.options.getString('sub');
            let subRoster = [];
            if (subRosterInput) {
                subRoster = await processRoster(subRosterInput, 'Sub Roster');
            }

            // Verificar duplicatas entre rosters
            if (mainRoster.length > 0 && subRoster.length > 0) {
                const mainIds = mainRoster.map(p => p.id);
                const subIds = subRoster.map(p => p.id);
                const duplicates = mainIds.filter(id => subIds.includes(id));

                if (duplicates.length > 0) {
                    return await interaction.reply({
                        content: '❌ Um jogador não pode estar em ambos os rosters ao mesmo tempo!',
                        flags: 64
                    });
                }
            }

            // Obter outras informações
            const logo = interaction.options.getAttachment('logo');
            const description = interaction.options.getString('descricao');
            const link = interaction.options.getString('link');
            const color = interaction.options.getString('cor');

            // Validar logo (se fornecida)
            if (logo && !logo.contentType?.startsWith('image/')) {
                return await interaction.reply({
                    content: '❌ O arquivo de logo deve ser uma imagem!',
                    flags: 64
                });
            }

            // Validar link (se fornecido)
            if (link && !isValidUrl(link)) {
                return await interaction.reply({
                    content: '❌ O link fornecido não é válido!',
                    flags: 64
                });
            }

            // Validar cor (se fornecida)
            if (color && !isValidColor(color)) {
                return await interaction.reply({
                    content: '❌ A cor fornecida não é válida! Use códigos hex (#FF0000) ou nomes de cores (red, blue, green, etc.)',
                    flags: 64
                });
            }

            // Atualizar dados da guilda
            if (mainRoster.length > 0) guild.mainRoster = mainRoster;
            if (subRoster.length > 0) guild.subRoster = subRoster;
            if (logo) {
                guild.logo = logo.url;
                console.log(`✅ Logo atualizada para guilda ${guild.name}: ${logo.url}`);
            }
            if (description) guild.description = description;
            if (link) guild.link = link;
            if (color) guild.color = normalizeColor(color);

            guild.updatedAt = new Date().toISOString();
            guild.updatedBy = interaction.user.id;

            // Salvar alterações
            fs.writeFileSync(guildsPath, JSON.stringify(guildsData, null, 2));

            // Criar embed de confirmação
            const embed = new EmbedBuilder()
                .setTitle('✅ Guilda Atualizada com Sucesso!')
                .setColor(guild.color || '#00ff00')
                .addFields(
                    { name: '🏰 Guilda', value: guild.name, inline: true },
                    { name: '👑 Leader', value: `<@${guild.leader.id}>`, inline: true },
                    { name: '⭐ Co-Leader', value: `<@${guild.coLeader.id}>`, inline: true }
                );

            if (guild.mainRoster.length > 0) {
                const mainRosterText = guild.mainRoster.map(p => {
                    const mention = `<@${p.id}>`;
                    return p.isMember === false ? `${mention} *(externo)*` : mention;
                }).join('\n');
                embed.addFields({ name: '🛡️ Main Roster', value: mainRosterText, inline: true });
            }

            if (guild.subRoster.length > 0) {
                const subRosterText = guild.subRoster.map(p => {
                    const mention = `<@${p.id}>`;
                    return p.isMember === false ? `${mention} *(externo)*` : mention;
                }).join('\n');
                embed.addFields({ name: '⚔️ Sub Roster', value: subRosterText, inline: true });
            }

            if (guild.description) {
                embed.addFields({ name: '📄 Descrição', value: guild.description, inline: false });
            }

            if (guild.link) {
                embed.addFields({ name: '🔗 Link', value: guild.link, inline: false });
            }

            if (guild.color) {
                embed.addFields({ name: '🎨 Cor do Embed', value: guild.color, inline: false });
            }

            if (guild.logo) {
                embed.setThumbnail(guild.logo);
            }

            embed.setFooter({ text: `Atualizada por ${interaction.user.username}` })
                 .setTimestamp();

            // Adicionar informações sobre usuários externos se houver
            const externalUsers = [...(mainRoster || []), ...(subRoster || [])].filter(p => p.isMember === false);
            if (externalUsers.length > 0) {
                embed.addFields({
                    name: '⚠️ Usuários Externos',
                    value: `${externalUsers.length} usuário(s) não são membros deste servidor`,
                    inline: false
                });
            }

            await interaction.reply({ embeds: [embed] });

            console.log(`✅ Guilda "${guild.name}" atualizada por ${interaction.user.username} (${interaction.user.id})`);

        } catch (error) {
            return await interaction.reply({
                content: error.message,
                flags: 64
            });
        }
    },
};

// Função para validar URL
function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}

// Função para validar cor
function isValidColor(color) {
    // Cores nomeadas válidas
    const namedColors = [
        'red', 'blue', 'green', 'yellow', 'orange', 'purple', 'pink', 'cyan',
        'magenta', 'lime', 'indigo', 'violet', 'brown', 'black', 'white', 'gray', 'grey',
        'gold', 'silver', 'navy', 'teal', 'olive', 'maroon', 'aqua', 'fuchsia'
    ];

    // Verificar se é uma cor nomeada
    if (namedColors.includes(color.toLowerCase())) {
        return true;
    }

    // Verificar se é um código hex válido
    const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
    return hexRegex.test(color);
}

// Função para normalizar cor (converter nomes para hex)
function normalizeColor(color) {
    const colorMap = {
        'red': '#FF0000',
        'blue': '#0000FF',
        'green': '#00FF00',
        'yellow': '#FFFF00',
        'orange': '#FFA500',
        'purple': '#800080',
        'pink': '#FFC0CB',
        'cyan': '#00FFFF',
        'magenta': '#FF00FF',
        'lime': '#00FF00',
        'indigo': '#4B0082',
        'violet': '#EE82EE',
        'brown': '#A52A2A',
        'black': '#000000',
        'white': '#FFFFFF',
        'gray': '#808080',
        'grey': '#808080',
        'gold': '#FFD700',
        'silver': '#C0C0C0',
        'navy': '#000080',
        'teal': '#008080',
        'olive': '#808000',
        'maroon': '#800000',
        'aqua': '#00FFFF',
        'fuchsia': '#FF00FF'
    };

    // Se for uma cor nomeada, converter para hex
    if (colorMap[color.toLowerCase()]) {
        return colorMap[color.toLowerCase()];
    }

    // Se for hex, retornar como está (mas em maiúsculo)
    return color.toUpperCase();
}

// Comando adicional para ajudar a encontrar IDs de usuários
module.exports.findUser = {
    data: new SlashCommandBuilder()
        .setName('buscar-usuario')
        .setDescription('Busca o ID de um usuário pelo nome')
        .addStringOption(option =>
            option.setName('nome')
                .setDescription('Nome do usuário para buscar')
                .setRequired(true)),

    async execute(interaction) {
        const searchName = interaction.options.getString('nome').toLowerCase();

        try {
            const members = await interaction.guild.members.fetch();
            const matches = members.filter(member => 
                member.user.username.toLowerCase().includes(searchName) ||
                member.displayName.toLowerCase().includes(searchName)
            );

            if (matches.size === 0) {
                return await interaction.reply({
                    content: `❌ Nenhum usuário encontrado com o nome "${searchName}"`,
                    flags: 64
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('🔍 Usuários Encontrados')
                .setColor('#0099ff');

            let description = '';
            matches.first(10).forEach(member => {
                description += `**${member.displayName}** (@${member.user.username})\nID: \`${member.user.id}\`\n\n`;
            });

            if (matches.size > 10) {
                description += `... e mais ${matches.size - 10} usuários`;
            }

            embed.setDescription(description);

            await interaction.reply({ embeds: [embed], flags: 64 });

        } catch (error) {
            await interaction.reply({
                content: '❌ Erro ao buscar usuários',
                flags: 64
            });
        }
    }
};