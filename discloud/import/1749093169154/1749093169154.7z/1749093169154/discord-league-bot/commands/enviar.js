const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('enviar')
        .setDescription('Envia uma guilda no canal configurado (apenas moderadores)')
        .addStringOption(option =>
            option.setName('guilda')
                .setDescription('Nome da guilda para enviar')
                .setRequired(true)),

    async execute(interaction) {
        const guildName = interaction.options.getString('guilda');
        const moderatorRoles = ['1353770746660524123', '1348060399219773440']; // IDs dos cargos autorizados

        // Verificar se o usuário é moderador
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const isModerator = member.roles.cache.some(role => moderatorRoles.includes(role.id));

        if (!isModerator) {
            return await interaction.reply({
                content: '❌ Apenas moderadores podem usar este comando!',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Carregar dados das guildas
        const guildsPath = path.join(__dirname, '..', 'guilds.json');

        if (!fs.existsSync(guildsPath)) {
            return await interaction.reply({
                content: '❌ Nenhuma guilda foi registrada ainda!',
                flags: 64
            });
        }

        const guildsData = JSON.parse(fs.readFileSync(guildsPath, 'utf8'));
        const guild = guildsData.guilds[guildName.toLowerCase()];

        if (!guild) {
            // Sugerir guildas disponíveis
            const availableGuilds = Object.values(guildsData.guilds).map(g => g.name).join(', ');
            return await interaction.reply({
                content: `❌ Guilda "${guildName}" não encontrada!\n\n**Guildas disponíveis:** ${availableGuilds}`,
                flags: 64
            });
        }

        // Carregar configurações do canal
        const configPath = path.join(__dirname, '..', 'config.json');

        if (!fs.existsSync(configPath)) {
            return await interaction.reply({
                content: '❌ Canal não configurado! Use `/definir-canal` para configurar um canal primeiro.',
                flags: 64
            });
        }

        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

        if (!config.guildViewChannel) {
            return await interaction.reply({
                content: '❌ Canal de guildas não configurado! Use `/definir-canal` para configurar.',
                flags: 64
            });
        }

        try {
            // Buscar o canal
            const channel = await interaction.client.channels.fetch(config.guildViewChannel);

            if (!channel) {
                return await interaction.reply({
                    content: '❌ Canal configurado não encontrado! Verifique se o canal ainda existe.',
                    flags: 64
                });
            }

            // Verificar se o bot tem permissões para enviar mensagens
            if (!channel.permissionsFor(interaction.client.user).has(['SendMessages', 'EmbedLinks'])) {
                return await interaction.reply({
                    content: '❌ Não tenho permissões para enviar mensagens no canal configurado!',
                    flags: 64
                });
            }

            // Criar embed básico da guilda (estilo da imagem)
            const embed = new EmbedBuilder()
                .setTitle(`🏰 ${guild.name}`)
                .setColor(guild.color || '#FFD700')
                .setDescription('Nova guilda registrada no sistema!')
                .addFields(
                    { name: '👑 Leader', value: `<@${guild.leader.id}>`, inline: true },
                    { name: '⭐ Co-Leader', value: `<@${guild.coLeader.id}>`, inline: true },
                    { name: '📅 Registrada', value: `<t:${Math.floor(new Date(guild.createdAt).getTime() / 1000)}:R>`, inline: true }
                );

            // Main Roster
            if (guild.mainRoster && guild.mainRoster.length > 0) {
                const mainRosterText = guild.mainRoster.map((p, index) => `${index + 1}. <@${p.id}>`).join('\n');
                embed.addFields({ name: '🛡️ Main Roster', value: mainRosterText, inline: true });
            } else {
                embed.addFields({ name: '🛡️ Main Roster', value: '*Será definido posteriormente*', inline: true });
            }

            // Sub Roster
            if (guild.subRoster && guild.subRoster.length > 0) {
                const subRosterText = guild.subRoster.map((p, index) => `${index + 1}. <@${p.id}>`).join('\n');
                embed.addFields({ name: '⚔️ Sub Roster', value: subRosterText, inline: true });
            } else {
                embed.addFields({ name: '⚔️ Sub Roster', value: '*Será definido posteriormente*', inline: true });
            }

            // Adicionar logo se existir
            if (guild.logo) {
                embed.setThumbnail(guild.logo);
            }

            // Adicionar informação sobre quem registrou
            embed.addFields({
                name: '📝 Registrada por',
                value: `<@${guild.createdBy}>`,
                inline: false
            });

            embed.setFooter({ text: `Use /visualizar ${guild.name} para ver detalhes completos` })
                 .setTimestamp();

            // Enviar no canal
            const message = await channel.send({ 
                content: `🎉 **Guilda Enviada!** 🎉`,
                embeds: [embed] 
            });

            // Responder ao moderador
            await interaction.reply({
                content: `✅ Guilda **${guild.name}** enviada com sucesso no canal <#${channel.id}>!\n\n[📩 Ver mensagem](${message.url})`,
                flags: 64
            });

            console.log(`📤 Guilda "${guild.name}" enviada por ${interaction.user.username} (${interaction.user.id}) no canal ${channel.name}`);

        } catch (error) {
            console.error('❌ Erro ao enviar guilda:', error);

            let errorMessage = '❌ Erro ao enviar a guilda no canal configurado!';

            if (error.code === 10003) {
                errorMessage = '❌ Canal configurado não encontrado! Use `/definir-canal` para reconfigurar.';
            } else if (error.code === 50013) {
                errorMessage = '❌ Não tenho permissões para enviar mensagens no canal configurado!';
            }

            await interaction.reply({
                content: errorMessage,
                flags: 64
            });
        }
    },
};