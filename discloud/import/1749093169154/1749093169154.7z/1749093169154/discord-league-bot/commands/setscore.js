const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Cargos autorizados a usar o comando
const AUTHORIZED_ROLES = [
    '1358557290835218534',
    '1274456218794070042', 
    '1341162654374297630',
    '1348060399219773440',
    '1348059318028861450'
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setscore')
        .setDescription('Define o score (vitórias/derrotas) de uma guilda')
        .addStringOption(option =>
            option.setName('guilda')
                .setDescription('Nome da guilda')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('vitorias')
                .setDescription('Número de vitórias')
                .setRequired(true)
                .setMinValue(0))
        .addIntegerOption(option =>
            option.setName('derrotas')
                .setDescription('Número de derrotas')
                .setRequired(true)
                .setMinValue(0)),

    async execute(interaction) {
        // Verificar permissões
        const userRoles = interaction.member.roles.cache.map(role => role.id);
        const hasPermission = AUTHORIZED_ROLES.some(roleId => userRoles.includes(roleId));

        if (!hasPermission) {
            return await interaction.reply({
                content: '❌ Você não tem permissão para usar este comando!',
                flags: 64 // EPHEMERAL flag
            });
        }

        const guildName = interaction.options.getString('guilda');
        const wins = interaction.options.getInteger('vitorias');
        const losses = interaction.options.getInteger('derrotas');

        // Carregar dados das guildas
        const guildsPath = path.join(__dirname, '..', 'guilds.json');

        if (!fs.existsSync(guildsPath)) {
            return await interaction.reply({
                content: '❌ Nenhuma guilda foi registrada ainda!',
                flags: 64 // EPHEMERAL flag
            });
        }

        let guildsData = JSON.parse(fs.readFileSync(guildsPath, 'utf8'));
        const guilds = guildsData.guilds;

        // Verificar se a guilda existe
        const guild = guilds[guildName.toLowerCase()];

        if (!guild) {
            const availableGuilds = Object.values(guilds).map(g => g.name).join(', ');
            return await interaction.reply({
                content: `❌ Guilda "${guildName}" não encontrada!\n\n**Guildas disponíveis:** ${availableGuilds}`,
                flags: 64 // EPHEMERAL flag
            });
        }

        // Atualizar o score da guilda
        guild.score = {
            wins: wins,
            losses: losses
        };

        // Adicionar informações de quem atualizou
        guild.updatedAt = new Date().toISOString();
        guild.updatedBy = interaction.user.id;

        // Salvar dados atualizados
        try {
            fs.writeFileSync(guildsPath, JSON.stringify(guildsData, null, 2), 'utf8');
        } catch (error) {
            console.error('Erro ao salvar dados das guildas:', error);
            return await interaction.reply({
                content: '❌ Erro ao salvar os dados. Tente novamente.',
                flags: 64 // EPHEMERAL flag
            });
        }

        // Calcular estatísticas
        const totalGames = wins + losses;
        const winRate = totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;

        // Criar embed de confirmação
        const embed = new EmbedBuilder()
            .setTitle(`📊 Score Atualizado - ${guild.name}`)
            .setColor('#00FF00')
            .addFields(
                { name: '🏆 Vitórias', value: wins.toString(), inline: true },
                { name: '💀 Derrotas', value: losses.toString(), inline: true },
                { name: '🎯 Taxa de Vitória', value: `${winRate}%`, inline: true },
                { name: '🎮 Total de Jogos', value: totalGames.toString(), inline: true },
                { name: '👤 Atualizado por', value: `<@${interaction.user.id}>`, inline: true },
                { name: '⏰ Data/Hora', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            )
            .setFooter({ text: `Guilda: ${guild.name}` })
            .setTimestamp();

        // Adicionar cor baseada na performance
        if (winRate >= 70) {
            embed.setColor('#00FF00'); // Verde para boa performance
        } else if (winRate >= 50) {
            embed.setColor('#FFFF00'); // Amarelo para performance média
        } else if (totalGames > 0) {
            embed.setColor('#FF6600'); // Laranja para performance baixa
        } else {
            embed.setColor('#808080'); // Cinza para sem jogos
        }

        await interaction.reply({ embeds: [embed] });

        // Log no console
        console.log(`📊 Score da guilda "${guild.name}" atualizado por ${interaction.user.username} (${interaction.user.id}) - ${wins}W/${losses}L`);
    },
};