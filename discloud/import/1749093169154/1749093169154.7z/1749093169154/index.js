const { Client, Collection, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Criar uma nova instância do cliente
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// Criar uma coleção para armazenar os comandos
client.commands = new Collection();

// Função para carregar comandos da pasta /commands
function loadCommands() {
    const commandsPath = path.join(__dirname, 'commands');

    // Verificar se a pasta commands existe
    if (!fs.existsSync(commandsPath)) {
        console.log('Pasta /commands não encontrada. Criando...');
        fs.mkdirSync(commandsPath);
        return;
    }

    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);

        // Verificar se o comando tem as propriedades necessárias
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            console.log(`✅ Comando ${command.data.name} carregado com sucesso!`);
        } else {
            console.log(`⚠️ O comando em ${filePath} está faltando propriedade "data" ou "execute".`);
        }
    }
}

// Evento quando o bot está pronto
client.once('ready', () => {
    console.log(`🤖 Bot logado como ${client.user.tag}!`);
    console.log(`📊 Servindo ${client.guilds.cache.size} servidor(es)`);

    // Definir status do bot
    client.user.setActivity('seus comandos!', { type: 'WATCHING' });
});

// Evento para interações (comandos slash)
client.on('interactionCreate', async interaction => {
    // Verificar se é um comando slash
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);

    if (!command) {
        console.error(`Comando ${interaction.commandName} não encontrado.`);
        return;
    }

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(`Erro ao executar o comando ${interaction.commandName}:`, error);

        // Responder com erro para o usuário
        const errorMessage = 'Houve um erro ao executar este comando!';

        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: errorMessage, flags: 64 });
        } else {
            await interaction.reply({ content: errorMessage, flags: 64 });
        }
    }
});

// Evento para erros
client.on('error', error => {
    console.error('Erro no cliente Discord:', error);
});

// Inicializar arquivo de guildas se não existir
function initializeGuildsFile() {
    const guildsPath = path.join(__dirname, 'guilds.json');
    if (!fs.existsSync(guildsPath)) {
        fs.writeFileSync(guildsPath, JSON.stringify({ guilds: {} }, null, 2));
        console.log('📁 Arquivo guilds.json criado');
    }
}

// Carregar comandos e inicializar sistema
loadCommands();
initializeGuildsFile();

// Login do bot
client.login(process.env.DISCORD_TOKEN);